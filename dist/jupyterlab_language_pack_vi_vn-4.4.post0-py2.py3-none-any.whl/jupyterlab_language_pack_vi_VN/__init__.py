# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.

__version__ = "4.4.post0"
