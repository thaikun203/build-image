import logging
from tornado.web import HTTPError
from jupyter_server.services.contents.manager import ContentsManager
from datetime import datetime, timezone

from .checkpoints import NoOpCheckpoints

log = logging.getLogger("DBContentManager")


class DBContentManager(ContentsManager):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.checkpoints = NoOpCheckpoints(parent=self)

    # =====================================================
    # FS flags (NHẤT QUÁN)
    # =====================================================
    def is_hidden(self, path):
        return False

    def file_exists(self, path):
        return path == ""   # 🔥 ROOT TỒN TẠI

    def dir_exists(self, path):
        return path == ""   # 🔥 ROOT TỒN TẠI

    def is_dir(self, path):
        return path == ""   # 🔥 ROOT LÀ DIRECTORY

    # =====================================================
    # GET
    # =====================================================
    def get(self, path, content=True, **kwargs):
        # 🔥 BẮT BUỘC: ROOT DIRECTORY
        if path in ("", "/"):
            now = datetime.now(timezone.utc)
            return {
                "name": "",
                "path": "",
                "type": "directory",
                "content": [] if content else None,
                "format": "json" if content else None,
                "created": now,
                "last_modified": now,
                "writable": False,
                "mimetype": None,
            }

        raise HTTPError(404)

    # =====================================================
    # DISABLE WRITE APIs
    # =====================================================
    def save(self, model, path=""):
        raise HTTPError(405)

    def delete(self, path):
        raise HTTPError(405)

    def rename(self, old_path, new_path):
        raise HTTPError(405)

    def copy(self, from_path, to_path=None):
        raise HTTPError(405)

    def new_untitled(self, path="", type="", ext=""):
        raise HTTPError(405)
