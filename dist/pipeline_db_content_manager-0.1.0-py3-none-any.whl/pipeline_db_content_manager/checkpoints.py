from datetime import datetime
from tornado.web import HTTPError
from jupyter_server.services.contents.checkpoints import Checkpoints

class NoOpCheckpoints(Checkpoints):
    def list_checkpoints(self, path):
        return []

    def create_checkpoint(self, contents_mgr, path):
        return {
            "id": "noop",
            "path": path,
            "last_modified": datetime.utcnow().isoformat() + "Z",
        }

    def delete_checkpoint(self, path, checkpoint_id):
        return

    def restore_checkpoint(self, path, checkpoint_id):
        raise HTTPError(400, "Checkpoints are not supported")
